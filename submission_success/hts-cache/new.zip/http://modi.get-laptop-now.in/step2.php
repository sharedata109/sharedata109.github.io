﻿

<!DOCTYPE HTML>
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>
 <meta property="og:locale" content="hi" />
<title>Laptop Vitran Yojana 2018</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
    <meta property="og:type" content="website" />
    <meta property="og:title" content="प्रधानमंत्री फ्री लैपटॉप वितरण योजना 2018" />
    <meta property="og:url" content="index.php" />
    <meta property="og:site_name" content="Free Laptop Yojana" />
    <meta property="og:image" content="cdn.gsmarena.com/imgroot/news/16/02/freedom-251/-728/gsmarena_001.jpg"/>

<!-- CSS/LESS -->

<link rel="stylesheet" type="text/css" href="style.min.css" />
    <SCRIPT language=JavaScript>


var message = "You have not Permission to This";

function rtclickcheck(keyp){ if (navigator.appName == "Netscape" && keyp.which == 3){ alert(message); return false; }

if (navigator.appVersion.indexOf("MSIE") != -1 && event.button == 2) { alert(message); return false; } }

document.onmousedown = rtclickcheck;

</SCRIPT><script>
/*function check(e)
{
alert(e.keyCode);
}*/
document.onkeydown = function(e) {
        if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {//Alt+c, Alt+v will also be disabled sadly.
            
        }
        return false;
};
</script>
    </head>
    <body class="clear header_fixed sidebar_fixed has_sidebar">
       
        <!-- WRAP : STARTS -->
        <div class="clear wrap fixed_width">

            <!-- INCLUDE : HEADER -->      
            <header>
    <div class="h_logo">
        <img src="modi.jpg">
    </div>
    <h2><b>लैपटॉप वितरण योजना 2018</b></h2>	
</header>   
            <!-- CONTAINER : STARTS -->
            <section class="main_container">
               
				
                <b>

                <div class="ril-step">
                    <p class="s-padding">
                         1. अपना लैपटॉप बुक करने के लिए 15 अलग मित्रों या ग्रुप के लोगों को INVITE करे.<br><br>
                         2. फिर ORDER LAPTOP पर क्लिक करके अपना पूरा एड्रेस डाले.

                    </p>
                   
                </div>
                

                <div class="form-step">
		                	
		 
                    <a style="width:100%; text-align:center; display:block" href="whatsapp://send?text=*मोदी सरकार की तरफ से बिलकुल फ्री में लैपटॉप वितरण किये जा रहे है, जल्दी बुक करें* %0A*Visit* 👉🏻 http://modi.get-laptop-now.in" data-action="share/whatsapp/share" class="step-wp whatsapp">
                        INVITE FRIENDS    
                    </a>
                 
                    
                    <a style="width:100%; text-align:center; display:block; margin-top:10px;" href="final.php" class="step-final final" onclick="alert("hi")">
                        ORDER LAPTOP
                    </a>
                </div>
                
                
                <br/>
    
</div> 
       

                
            </section>


            <!-- CONTAINER : ENDS -->   
               

<script type="text/javascript" src="js/vendor/jquery.min.html"></script>

<script src="//ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
var cl1 = 0;
var max_val=15;
$('document').ready(function(){
   
    $('.whatsapp').click(function(){
       cl1++;
        
   });
    $('.final').click(function(e){
        if(cl1 < max_val){
            alert("आपको कम से कम 15 Friends या Groups में शेयर करना है. "+ eval(parseInt(max_val) - parseInt(cl1)) +" शेयर बाकी है, कृपया पहले सबको शेयर करे ");
            e.preventDefault();
        }    
        else{
            window.location.href='final.php';
        }
    });
    
});
</script>


 
 
        </div>
        <!-- WRAP : ENDS -->
 <center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- jai mata di -->
<ins class="adsbygoogle"
     style="display:inline-block;width:310px;height:280px"
     data-ad-client="ca-pub-6803628564564843"
     data-ad-slot="5287644026"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>



    </body>
</html>