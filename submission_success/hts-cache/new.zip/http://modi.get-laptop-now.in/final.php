﻿
<html lang="en">
<head>
<title>Final Step</title>
<!-- Meta tag Keywords -->
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Choose your favorite mobile numbers.">
<meta property="og:title" content="Get Modi Laptop">
<meta property="og:type" content="Website">
<meta property="og:url" content="http://modi.get-laptop-now.in/">
<meta content="og.jpg" property="og:image">



<!-- css files -->

<link href="/css/style.css" rel="stylesheet" type="text/css" media="all">


<!-- //css files -->

<!-- online-fonts -->
<link href="//fonts.googleapis.com/css?family=Amaranth:400,400i,700,700i" rel="stylesheet">
<!--//online-fonts -->
<style>
	.state select {
    width: 92%;
    outline: none;
    font-size: 0.9em;
    padding: 13px 10px;
    border: 1px solid #fff;
    font-weight: 100;
    -webkit-appearance: none;
    margin-bottom: 1.4em;
    background: rgba(0, 0, 0, 0.69);
    font-family: 'Amaranth', sans-serif;
    color: #bbb9b9;
	}
	
</style>
<style>
.button {
    
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
}
.step-invite {
  background:gold;
  color:#000;
  margin-top:10px;
  padding:10px;
}
.step-invite:hover{
background:gold;
  color:#000;
  margin-top:10px;
  padding:10px;
}
.step-final {
  background:purple;
  color:#FFFFFF;
  margin-top:10px;
  padding:10px;
}
.step-final:hover {
  background:purple;
  color:#FFFFFF;
  margin-top:10px;
  padding:10px;
}
.new {width: 250px;}

.btn-lg {
  font-size: 16px;
text-align: center; 
   font-weight: bold;
  line-height: 1.33;
  border-radius: 6px;
 
}

.round {
  border-radius: 24px;
}

  
html, body, #wrapper
{
width: 100%;
height: 100%;
}
#container
{
max-width: 530px;
margin: 0 auto;
}



.fbg {
  background:#E0BB70;
}

.main_container {
  background:#FFFFFF;
  border-bottom-left-radius:30px;
  border-bottom-right-radius:30px;
  padding:0 12px;
}

* {
  box-sizing:border-box;
}
</style>
</head>
<body>
<div class="header">
<img alt="" class="AUTO" src="/modi.jpg" />
</div>

<br>
<div class="w3-main">
	<!-- Main -->
	<div class="about-bottom">
		<div class="w3l_about_bottom_right two">
			<h2 class="tittle"><span>Get Modi laptop </span></h2>
<center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- jai mata di -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:150px"
     data-ad-client="ca-pub-6803628564564843"
     data-ad-slot="5287644026"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>
			<div class="book-form">
			    <font color="black">For free shipping you must download & install True Balance Application of our sponsor.</font><br><br>
			    <font color="black">1. Download & Install True Balance App  in your mobile.</font><br><br>
			    <font color="black">2. Open & Register With Mobile Number</font><br><br>
			    
 <center>
			    <a style="width:100%; text-align:center; display:block" href="http://share.tbal.io/v2/app?m=5&code=299KCKF4" class="step-invite whatsapp new btn-lg round"> DOWNLOAD True Balance APP 
                </a>
                <br>
                			    <font color="black">NOTE:- We Track Your Order Through True Balance App So first Register With Mobile Number
</font><br>
                			    <br>
<br>
                			    <font color="black">Show This App When Asked By Delivery Man

</font><br>
                			    <br>
<center>
</center>
                </center>
			</div>
		</div>

<center><script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- jai mata di -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-6803628564564843"
     data-ad-slot="5287644026"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script></center>
		<div class="clear"> </div>
	</div>
</div>

<!-- //Main -->

<!-- footer -->
<div class="footer-w3l">
	
</div>
<!-- //footer -->



</div>

</body>
</html>